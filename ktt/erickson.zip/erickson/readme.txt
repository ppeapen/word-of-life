After downloading and extracting this archive, open the file "index.html" using your computer's web browser. Follow the links on the page.

If you downloaded this archive on your phone, extract the zipped file. Use the phone's browser to open "index.html" in the unzipped folder.
